Dash Kieler

No time for a readme, sorry, Will probably submit again.
Code runs pretty well, havent gotten a chance to test eveything.
I tryied to get an extension, but I dont think goldschmit got through to my email yet.
